		
	</div><!-- end:container-wrap -->
</div><!-- end:colorlib-page -->

	<?php wp_footer(); ?>
	
	</body>
</html>

