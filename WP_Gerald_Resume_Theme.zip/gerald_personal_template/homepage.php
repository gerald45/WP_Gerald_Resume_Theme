<?php

/*
*Template Name: Homepage
*/

get_header(); ?>

<div id="colorlib-main">
			
		  <?php
			include get_template_directory().'/sections-display/section-display-slider.php';
		  	include get_template_directory().'/sections-display/section-display-about.php';
			include get_template_directory().'/sections-display/section-display-services.php';
			include get_template_directory().'/sections-display/section-display-counter.php';
			include get_template_directory().'/sections-display/section-display-skills.php';
			include get_template_directory().'/sections-display/section-display-education.php';
			include get_template_directory().'/sections-display/section-display-experience.php';
			include get_template_directory().'/sections-display/section-display-portfolio.php';
			//include get_template_directory().'/sections-display/section-display-blog.php';
			include get_template_directory().'/sections-display/section-display-contactform.php';
		?>
			
			
		</div><!-- end:colorlib-main -->
<?php get_footer(); ?>