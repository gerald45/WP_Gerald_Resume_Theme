<?php

	function gerald_homepage_body($wp_customize) {

		$wp_customize->add_panel( 'homepage_panel', array(
		  'priority'       => 10,
		  'capability'     => 'edit_theme_options',
		  'theme_supports' => '',
		  'title'          => __('Home Page', 'Gerald Theme'),
		  'description'    => __('Homepage Settings fo Gerald Theme', 'Gerald Theme'),
		));

		//slider section area
		$wp_customize->add_section('gerald-slider-section', array(
			'title' => 'Slider Section',
			'panel' => 'homepage_panel'
		));

		for( $i = 1; $i<3; $i++ ) {

			$wp_customize->add_setting('gerald-slider'.$i.'-image');
			$wp_customize->add_control(new WP_Customize_Cropped_Image_Control($wp_customize, 'gerald-slider'.$i.'-image-control', array(
			'label' => 'Slider'.$i." ". ' Image',
			'section' => 'gerald-slider-section',
			'settings' => 'gerald-slider'.$i.'-image'
			)));

			$wp_customize->add_setting('gerald-slider'.$i.'-h1', array(
			'default' => 'My name is Gerald'
			));
			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-slider'.$i.'-h1-control', array(
			'label' =>  'Slider'.$i." ".'Heading',
			'section' => 'gerald-slider-section',
			'settings' => 'gerald-slider'.$i.'-h1'
			)));

			$wp_customize->add_setting('gerald-slider'.$i.'-h2', array(
			'default' => 'Expert Web Developer'
			));
			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-slider'.$i.'-h2-control', array(
			'label' =>  'Slider'.$i." ".'Sub Heading',
			'section' => 'gerald-slider-section',
			'settings' => 'gerald-slider'.$i.'-h2'
			)));

		}


		/* about-us section area */
			$wp_customize->add_section('gerald-about-section', array(
				'title' => 'About Section',
				'panel' => 'homepage_panel'
			));

			//about intro
			$wp_customize->add_setting('gerald-about-heading', array(
			'default' => 'ABOUT US'
			));
			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-about-heading-control', array(
			'label' =>  'About Us Heading',
			'section' => 'gerald-about-section',
			'settings' => 'gerald-about-heading'
			)));

			$wp_customize->add_setting('gerald-about-title', array(
			'default' => 'Who Am I?	'
			));
			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-about-title-control', array(
			'label' =>  'About Us Title',
			'section' => 'gerald-about-section',
			'settings' => 'gerald-about-title'
			)));

			$wp_customize->add_setting('gerald-about-text', array(
			'default' => 'Hi I am Gerald Homboy On her way she met a copy. The copy warned the Little Blind Text, that where it came from it would have been rewritten a thousand times and everything that was left from its origin would be the word "and" and the Little Blind Text should turn around and return to its own, safe country.'
			));
			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-about-text-control', array(
			'label' =>  'About Us Text',
			'type'	=>	'textarea',
			'section' => 'gerald-about-section',
			'settings' => 'gerald-about-text'
			)));

			//about-us service icon
			for( $i = 1; $i<5; $i++ ) {
				$wp_customize->add_setting('gerald-about-service-iconclass'.$i, array(
				'default' => 'icon-bulb'
				));
				$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-about-service-iconclass'.$i.'-control', array(
				'label' =>  'Service Icon Class'.$i,
				'section' => 'gerald-about-section',
				'settings' => 'gerald-about-service-iconclass'.$i
				)));

				$wp_customize->add_setting('gerald-about-service-title'.$i, array(
				'default' => 'Web Design'
				));
				$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-about-service-title'.$i.'-control', array(
				'label' =>  'Service Title'.$i,
				'section' => 'gerald-about-section',
				'settings' => 'gerald-about-service-title'.$i
				)));
			}

			//about-us call action
			$wp_customize->add_setting('gerald-about-callact-text', array(
			'default' => 'I am happy to know you that 300+ projects done sucessfully!?	'
			));
			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-about-callact-text-control', array(
			'label' =>  'Call Action Text',
			'section' => 'gerald-about-section',
			'settings' => 'gerald-about-callact-text',
			'type'	=>	'textarea'
			)));

			$wp_customize->add_setting('gerald-about-callact-button', array(
			'default' => 'Hire Me!'
			));
			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-about-callact-button-control', array(
			'label' =>  'Call Action Button Text',
			'section' => 'gerald-about-section',
			'settings' => 'gerald-about-callact-button'
			)));

			$wp_customize->add_setting('gerald-about-callact-url', array(
			'default' => '#'
			));
			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-about-callact-url-control', array(
			'label' =>  'Call Action Button Link',
			'section' => 'gerald-about-section',
			'settings' => 'gerald-about-callact-url'
			)));
		/*End About Us*/

		/*service section area*/
			$wp_customize->add_section('gerald-services-section', array(
				'title' => 'Services Section',
				'panel' => 'homepage_panel'
			));

			//services intro
			$wp_customize->add_setting('gerald-services-heading', array(
			'default' => 'WHAT I DO?'
			));
			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-services-heading-control', array(
			'label' =>  'Services Heading',
			'section' => 'gerald-services-section',
			'settings' => 'gerald-services-heading'
			)));

			$wp_customize->add_setting('gerald-services-title', array(
			'default' => 'HERE ARE SOME OF MY EXPERTISE'
			));
			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-services-title-control', array(
			'label' =>  'Services Title',
			'section' => 'gerald-services-section',
			'settings' => 'gerald-services-title'
			)));

			//services icon
			for( $i = 1; $i<7; $i++ ) {

				$wp_customize->add_setting('gerald-services-title-iconclass'.$i, array(
				'default' => 'icon-bulb'
				));
				$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-about-service-iconclass'.$i.'-control', array(
				'label' =>  'Service Icon Class'.$i,
				'section' => 'gerald-services-section',
				'settings' => 'gerald-services-iconclass'.$i
				)));

				$wp_customize->add_setting('gerald-services-title'.$i, array(
				'default' => 'GRAPHIC DESIGN'
				));
				$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-services-title'.$i.'-control', array(
				'label' =>  'Services Title'.$i,
				'section' => 'gerald-services-section',
				'settings' => 'gerald-services-title'.$i
				)));

				$wp_customize->add_setting('gerald-services-text'.$i, array(
				'default' => 'Separated they live in Bookmarksgrove right at the coast of the Semantics'
				));
				$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-services-text'.$i.'-control', array(
				'label' =>  'Services Text'.$i,
				'section' => 'gerald-services-section',
				'settings' => 'gerald-services-text'.$i,
				'type'	=> 'textarea'
				)));

			}

		/*end of service section area*/	

		/*counter section*/
		$wp_customize->add_section('gerald-counter-section', array(
				'title' => 'Counter Section',
				'panel' => 'homepage_panel'
			));

		for( $i = 1; $i<4; $i++ ) {

			$wp_customize->add_setting('gerald-counter-title'.$i, array(
			'default' => 'Projects'.$i
			));
			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-counter-title'.$i.'-control', array(
			'label' =>  'Counter Title',
			'section' => 'gerald-counter-section',
			'settings' => 'gerald-counter-title'.$i
			)));

			$wp_customize->add_setting('gerald-counter-value'.$i, array(
			'default' => '309'+$i
			));
			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-counter-value'.$i.'-control', array(
			'label' =>  'Counter Value',
			'section' => 'gerald-counter-section',
			'settings' => 'gerald-counter-value'.$i
			)));
		}
			
		/*end counter section*/

		/*Skills Section*/
		$wp_customize->add_section('gerald-skills-section', array(
				'title' => 'Skills Section',
				'panel' => 'homepage_panel'
			));
			$wp_customize->add_setting('gerald-skills-heading', array(
			'default' => 'MY SPECIALTY?'
			));
			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-skills-heading-control', array(
			'label' =>  'Skills Heading',
			'section' => 'gerald-skills-section',
			'settings' => 'gerald-skills-heading'
			)));

			$wp_customize->add_setting('gerald-skills-subheading', array(
			'default' => 'MY SKILLS'
			));
			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-skills-subheading-control', array(
			'label' =>  'Skills Sub Heading',
			'section' => 'gerald-skills-section',
			'settings' => 'gerald-skills-subheading'
			)));

			$wp_customize->add_setting('gerald-skills-intro', array(
			'default' => 'The Big Oxmox advised her not to do so, because there were thousands of bad Commas, wild Question Marks and devious Semikoli, but the Little Blind Text didn’t listen. She packed her seven versalia, put her initial into the belt and made herself on the way.'
			));
			$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-skills-intro-control', array(
			'label' =>  'Skills Intro',
			'section' => 'gerald-skills-section',
			'settings' => 'gerald-skills-intro',
			'type'	=>	'textarea'
			)));

			//skills
			for( $i = 1; $i<7; $i++ ) {

				$wp_customize->add_setting('gerald-skills-title'.$i, array(
				'default' => 'Photoshop'
				));
				$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-skills-title'.$i.'-control', array(
				'label' =>  'Skills Title'.$i,
				'section' => 'gerald-skills-section',
				'settings' => 'gerald-skills-title'.$i
				)));

				$wp_customize->add_setting('gerald-skills-color'.$i, array(
				'default' => '#000000'
				));
				$wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'gerald-skills-color'.$i.'-control', array(
					'label'      => 'Choose Skill Color',
					'section'    => 'gerald-skills-section',
					'settings'   => 'gerald-skills-color'.$i
				)));

				$wp_customize->add_setting('gerald-skills-value'.$i, array(
				'default' => 75
				));
				$wp_customize->add_control(new WP_Customize_Control($wp_customize, 'gerald-skills-value'.$i.'-control', array(
				'label' =>  'Skills Rate'.$i,
				'section' => 'gerald-skills-section',
				'settings' => 'gerald-skills-value'.$i,
				)));

			}

		/*End Skills Section*/





	}

	add_action( 'customize_register', 'gerald_homepage_body');

?>