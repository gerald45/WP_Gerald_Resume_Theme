<?php
/*
* Kirki Config
*/
Kirki::add_config( 'gerald_theme_config', array(
	'capability'    => 'edit_theme_options',
	'option_type'   => 'theme_mod',
) );

//List of Panels
Kirki::add_panel( 'homepage_customizer', array(
    'priority'    => 10,
    'title'       => esc_html__( 'Homepage Customizers', 'geraldhomboy' ),
    'description' => esc_html__( 'Customize sections in homepage', 'geraldhomboy' ),
) );

/*load sections*/
require get_template_directory().'/sections-customizer/section-about.php';
require get_template_directory().'/sections-customizer/section-contact.php';
require get_template_directory().'/sections-customizer/section-counter.php';
require get_template_directory().'/sections-customizer/section-education.php';
require get_template_directory().'/sections-customizer/section-experience.php';
require get_template_directory().'/sections-customizer/section-services.php';
require get_template_directory().'/sections-customizer/section-skills.php';
require get_template_directory().'/sections-customizer/section-slider.php';