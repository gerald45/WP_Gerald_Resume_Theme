<?php
/*

@package geraldtheme
	==================
		ADMIN PAGE
	==================
*/

function gerald_add_admin_page() {

	add_menu_page( 'Gerald Theme Option', 'Gerald', 'manage_options', 'gerald_theme', 'gerald_theme_create_page', get_template_directory_uri().'/images/g.png',  110);

	add_submenu_page( 'gerald_theme', 'Gerald Theme Option', 'Settings', 'manage_options', 'gerald_theme', 'gerald_theme_create_page' );

	add_submenu_page( 'gerald_theme', 'Education Settings', 'Education', 'manage_options', 'gerald_theme_education', 'gerald_theme_settings_education' );

	//activate custom settings
	add_action( 'admin_init', 'gerald_custom_settings');

}

add_action( 'admin_menu', 'gerald_add_admin_page' );

function gerald_theme_create_page() {
	//generation of our admin page

	echo '<h1>Gerald Theme Option</h1>';
}

function gerald_theme_settings_education() {

}