<?php
/*
	======================================
	 Portfolio Work Experience Post Type
	=====================================
*/

function geraldtheme_portfolio_post_type() {

	$labels = array(
		'name' => 'Porfolio Projects',
		'singular' => 'Porfolio Project',
		'add_new' => 'Add Projects',
		'all_items' => 'All Projects',
		'add_new_item' => 'Add Project',
		'edit_item' => 'Edit Project',
		'new_item' => 'New Project',
		'view_item' => 'View Project',
		'search_item' => 'Search Project',
		'not_found' => 'No items found',
		'not_found_in_trash' => 'No items found in trash',
		'parent_item_colon' => 'Parent Item'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'supports' => array(
			'title',
			'editor',
			'excerpt',
			'thumbnail',
			'revisions'
		),
		//'taxonomies' => array('category', 'post_tag'),
		'menu_position' => 5,
		'exclude_from_search' => false
	);

	register_post_type( 'portfolio-projects', $args);

}

add_action( 'init', 'geraldtheme_portfolio_post_type' );


function geraldtheme_custom_taxonomies() {

	//add new taxonomy hierarchical

	$labels = array(
		'name' => 'Project Types',
		'singular_name' => 'Project Type',
		'seach_items' => 'Search Project Types',
		'all_items' => 'All Project Types',
		'parent_item' => 'Parent Project Type',
		'parent_item_colon' => 'Parent Project Type:',
		'edit_item' => 'Edit Project Type',
		'update_item' => 'Update Project Type',
		'add_new_item' => 'Add New Project Type',
		'new_item_type' => 'New Project Type',
		'menu_name'=> 'Project Type'
	);

	$args = array(
		'hierarchical' => true,
		'labels' => $labels,
		'show_ui' => true,
		'show_admin_column' => true,
		'query_var' => true,
		'rewrite' => array('slug' => 'project-type')
	);

	register_taxonomy( 'project-type', array('portfolio-projects'), $args);


	//add new taxonomy NOT hierarchical

	register_taxonomy( 'software', 'portfolio-projects', array(
		'label' => 'Software',
		'rewrite' => array('slug' => 'software'),
		'hierarchical' => false
	));

}

add_action( 'init', 'geraldtheme_custom_taxonomies');