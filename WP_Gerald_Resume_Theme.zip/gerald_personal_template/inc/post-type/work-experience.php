<?php
/*
	======================================
	 Portfolio Work Experience Post Type
	=====================================
*/

function geraldtheme_work_experience_post_type() {

	$labels = array(
		'name' => 'Work Experience',
		'singular' => 'Work Experience',
		'add_new' => 'Add Works',
		'all_items' => 'All Works',
		'add_new_item' => 'Add Work',
		'edit_item' => 'Edit Work',
		'new_item' => 'New Work',
		'view_item' => 'View Work',
		'search_item' => 'Search Works Experience',
		'not_found' => 'No items found',
		'not_found_in_trash' => 'No items found in trash',
		'parent_item_colon' => 'Parent Item'
	);
	$args = array(
		'labels' => $labels,
		'public' => true,
		'has_archive' => true,
		'publicly_queryable' => true,
		'query_var' => true,
		'rewrite' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'supports' => array(
			'title',
			'editor',
			'excerpt',
			'thumbnail',
			'revisions'
		),
		'taxonomies' => array('category', 'post_tag'),
		'menu_position' => 5,
		'exclude_from_search' => false
	);

	register_post_type( 'experience', $args);

}

add_action( 'init', 'geraldtheme_work_experience_post_type' );