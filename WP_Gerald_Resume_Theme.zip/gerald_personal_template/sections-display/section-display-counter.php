<div id="colorlib-counter" class="colorlib-counters" style="background-image: url(<?php echo get_theme_mod( 'sec_counter_image'); ?>);" data-stellar-background-ratio="0.5">
				<div class="overlay"></div>
				<div class="colorlib-narrow-content">
					<div class="row">
					</div>

						<?php $counter_settings = get_theme_mod( 'sec_data_counter');

								//Columns must be a factor of 12 (1,2,3,4,6,12)
								$numOfCols = 4;
								$rowCount = 0;
								$bootstrapColWidth = 12 / $numOfCols;
							?>
					<div class="row">

						<?php foreach( $counter_settings as $counter_setting ) :?>
						<div class="col-md-<?php echo $bootstrapColWidth; ?> text-center animate-box">
							<span class="colorlib-counter js-counter" data-from="0" data-to="<?php echo $counter_setting['counter_data_value']; ?>" data-speed="<?php echo get_theme_mod( 'sec_data_speed_services'); ?>" data-refresh-interval="<?php echo get_theme_mod('sec_data_rfsh_interval_services'); ?>"></span>
							<span class="colorlib-counter-label"><?php echo $counter_setting['counter_title']; ?></span>
						</div>

							<?php
								    $rowCount++;
								    if($rowCount % $numOfCols == 0) echo '</div><div class="row">';
								 endforeach; 
								 unset($numOfCols, $rowCount, $bootstrapColWidth);
							 ?>


					</div>

				</div>
			</div>