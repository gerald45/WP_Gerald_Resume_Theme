<section class="colorlib-education" data-section="education">
				<div class="colorlib-narrow-content">
					<div class="row">
						<div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
							<span class="heading-meta"><?php echo get_theme_mod( 'sec_title_education' ); ?></span>
							<h2 class="colorlib-heading animate-box"><?php echo get_theme_mod( 'sec_heading_education' ); ?></h2>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 animate-box" data-animate-effect="fadeInLeft">
							<div class="fancy-collapse-panel">
								<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

									<?php $sec_education_lists = get_theme_mod( 'sec_education_list');
										$color = 1;
										$number=1;
										
									?>
									
									<?php foreach( $sec_education_lists as $sec_education_list ) :?>
									
									<div class="panel panel-default">
									    <div class="panel-heading" role="tab" id="heading<?php echo $number; ?>">
									        <h4 class="panel-title">
									            <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo $number; ?>" aria-expanded="true" aria-controls="collapse<?php echo $number; ?>"><?php echo $sec_education_list['education_level'];  ?>
									            </a>
									        </h4>
									    </div>
									    <div id="collapse<?php echo $number; ?>" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading<?php echo $number; ?>">
									         <div class="panel-body"><?php echo $sec_education_list['education_details'];  ?></div>
									    </div>
									</div>
									<?php $number++; endforeach; ?>

								</div>
							</div>
						</div>
					</div>
				</div>
			</section>