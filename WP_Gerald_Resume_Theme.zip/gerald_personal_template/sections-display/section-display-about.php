<?php $chkvalue = get_theme_mod( 'sec_option_about', true ); ?>
<section class="colorlib-about" data-section="about" style="<?php echo ($chkvalue) ? '' : 'display:none'; ?>">
				<div class="colorlib-narrow-content">
					<div class="row">
						<div class="col-md-12">
							<div class="row row-bottom-padded-sm animate-box" data-animate-effect="fadeInLeft">
								<div class="col-md-12">
									<div class="about-desc">
										<span class="heading-meta">About Us</span>
										<h2 class="colorlib-heading">Who Am I?</h2>
										<p><?php echo get_theme_mod('sec_p_about'); ?></p>
									</div>
								</div>
							</div>

							<?php $about_expertise_settings = get_theme_mod( 'sec_expertise_about');

								//Columns must be a factor of 12 (1,2,3,4,6,12)
								$numOfCols = 4;
								$rowCount = 0;
								$bootstrapColWidth = 12 / $numOfCols;
							?>
							<div class="row">
							<?php foreach( $about_expertise_settings as $about_expertise_setting ) :?>  
							        <div class="col-md-<?php echo $bootstrapColWidth; ?> animate-box" data-animate-effect="<?php echo $about_expertise_setting['box_animation'];  ?>">
										<div class="services" style="border-bottom: 2px solid <?php echo $about_expertise_setting['expertise_border_color'] ?>;">
											<span class="icon2"><i class="<?php echo $about_expertise_setting['expertise_icon_class'];  ?>" style="color:<?php echo $about_expertise_setting['expertise_icon_color'] ?>;"></i></span>
											<h3><?php echo $about_expertise_setting['expertise_title'];  ?></h3>
										</div>
									</div>

							<?php
								    $rowCount++;
								    if($rowCount % $numOfCols == 0) echo '</div><div class="row">';
								 endforeach; 
								 unset($numOfCols, $rowCount, $bootstrapColWidth);
							 ?>
							
							</div>

							<div class="row">
								<div class="col-md-12 animate-box" data-animate-effect="fadeInLeft">
									<div class="hire">
										<h2><?php echo get_theme_mod('sec_call_action_about'); ?></h2>
										<a href="<?php echo esc_url_raw (get_theme_mod('sec_call_action_about_btn_url')); ?>" class="btn-hire"><?php echo get_theme_mod('sec_call_action_about_btn_text'); ?></a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
