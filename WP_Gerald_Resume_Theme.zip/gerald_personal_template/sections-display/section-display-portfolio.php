<section class="colorlib-work" data-section="portfolio">
				<div class="colorlib-narrow-content">
					<div class="row">
						<div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
							<span class="heading-meta">My Work</span>
							<h2 class="colorlib-heading animate-box">Recent Work</h2>
						</div>
					</div>

					  <h2>Dynamic Tabs</h2>
					  <p>The <strong>show</strong> method shows the tab.</p>
					  <ul id ="tab-menu" class="nav nav-tabs">
					  
					  </ul>
					  <script>
							$(document).ready(function(){
							 $("#tab-menu").on("click", "li", function(){
							    $(".hide-class").hide();
							    var removeItemID = $(this).attr('id');
							    $("."+removeItemID).show();
							  });
							});
						</script>

					  	<?php 
							$args = array( 'post_type' => 'portfolio-projects'); 
							$loop = new WP_Query( $args );
							while ( $loop->have_posts() ) : $loop->the_post(); ?>
								<?php
									$term_list = wp_get_post_terms($post->ID, 'project-type');
									$i= 0;
									foreach($term_list as $term) { $i++;
									   if( get_post_meta($post->ID, '_yoast_wpseo_primary_project-type',true) == $term->term_id ) {
									     $menu_id = $term->slug; ?>

									     <script>
									     jQuery.fn.exists = function(){return this.length>0;}

											if (!$("#<?php echo $menu_id; ?>").exists()) {
												$("#tab-menu").append("<li id='<?php echo $menu_id; ?>'><a href='javascript:void(0)'><?php echo $term->name; ?></a></li>");
											}
									     </script>

									  <?php }
									}
								?>
								<div class="hide-class <?php echo $menu_id; ?>">
									<div class="col-md-6 animate-box" data-animate-effect="fadeInTop">
										<div class="project" style="background-image: url(<?php if ( has_post_thumbnail() ) { the_post_thumbnail_url(); } ?>);">
											<div class="desc">
												<div class="con">
													<h3><a href="#"><?php echo the_title(); ?></a></h3>
													<p class="icon">
														<!-- <span><a href="#"><i class="icon-share3"></i></a></span>
														<span><a href="#"><i class="icon-eye"></i> 100</a></span>
														<span><a href="#"><i class="icon-heart"></i> 49</a></span> -->
													</p>
												</div>
											</div>
										</div>
									</div>
								</div>

					    		
						<?php endwhile; ?>
						


					<!-- <div class="row">
						<div class="col-md-12 animate-box">
							<p><a href="#" class="btn btn-primary btn-lg btn-load-more">Load more <i class="icon-reload"></i></a></p>
						</div>
					</div> -->

				</div>
			</section>
