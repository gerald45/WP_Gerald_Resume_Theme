<section class="colorlib-skills" data-section="skills">
				<div class="colorlib-narrow-content">
					<div class="row">
						<div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
							<span class="heading-meta"><?php echo get_theme_mod( 'sec_title_skills'); ?></span>
							<h2 class="colorlib-heading animate-box"><?php echo get_theme_mod( 'sec_heading_skills'); ?></h2>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 animate-box" data-animate-effect="fadeInLeft">
							<p><?php get_theme_mod( 'sec_p_skills' ); ?></p>
						</div>

						<?php $sec_expertise_skills = get_theme_mod( 'sec_expertise_skills');
								$color = 1;
							
						?>
						<?php foreach( $sec_expertise_skills as $sec_expertise_skill ) :?>
						<div class="col-md-6 animate-box" data-animate-effect="fadeInUp">
							<div class="progress-wrap">
								<h3><?php echo $sec_expertise_skill['slider_range_title'];  ?></h3>
								<div class="progress">
								 	<div class="progress-bar color-<?php echo $color; ?>" role="progressbar" aria-valuenow="<?php echo $sec_expertise_skill['slider_range_value'];  ?>"
								  	aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $sec_expertise_skill['slider_range_value'];  ?>%">
								    <span><?php echo $sec_expertise_skill['slider_range_value'];  ?>%</span>
								  	</div>
								</div>
							</div>
						<style type="text/css">
							.progress-bar.color-<?php echo $color; ?> {
							    background: <?php echo $sec_expertise_skill['slider_range__clr'];  ?>;
							}
							.progress-bar.color-<?php echo $color; ?> span {
							    color: <?php echo $sec_expertise_skill['slider_range__clr'];  ?>;
							}
							.progress-bar.color-<?php echo $color; ?>:after {
							    background: <?php echo $sec_expertise_skill['slider_range__clr'];  ?>;
							}
						</style>
						</div>
						<?php $color++;
							endforeach; 
							unset($color);
						 ?>
					</div>
				</div>
			</section>
