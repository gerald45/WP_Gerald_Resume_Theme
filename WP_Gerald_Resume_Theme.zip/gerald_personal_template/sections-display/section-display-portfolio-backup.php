<section class="colorlib-work" data-section="portfolio">
				<div class="colorlib-narrow-content">
					<div class="row">
						<div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
							<span class="heading-meta">My Work</span>
							<h2 class="colorlib-heading animate-box">Recent Work</h2>
						</div>
					</div>

					<div class="row row-bottom-padded-sm animate-box" data-animate-effect="fadeInLeft">
						<div class="col-md-12">
							<p class="work-menu">
								<?php
									$terms = get_terms( array( 
									    'taxonomy' => 'project-type',
									    'parent'   => 0
									) );
									if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
									    foreach ( $terms as $term ) {
									        echo '<span><a id="'.$term->slug.'" class="active" href="#test">' . $term->name . '</a></span>';
									        
									    }
									}

								?>
							</p>
						</div>
					</div>

					<div class="container">
					  <h2>Dynamic Tabs</h2>
					  <p>The <strong>show</strong> method shows the tab.</p>
					  <ul class="nav nav-tabs">
					    <li class="active"><a href="#home">Home</a></li>
					    <li><a href="#menu1">Menu 1</a></li>
					    <li><a href="#menu2">Menu 2</a></li>
					    <li><a href="#menu3">Menu 3</a></li>
					  </ul>

					  <div class="tab-content">
					    <div id="home" class="tab-pane fade">
					      <h3>HOME</h3>
					      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
					    </div>
					    <div id="menu1" class="tab-pane fade">
					      <h3>Menu 1</h3>
					      <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					    </div>
					    <div id="menu2" class="tab-pane fade">
					      <h3>Menu 2</h3>
					      <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
					    </div>
					    <div id="menu3" class="tab-pane fade">
					      <h3>Menu 3</h3>
					      <p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
					    </div>
					  </div>
					</div>

						<script>
							$(document).ready(function(){
							  $(".nav-tabs a").click(function(){
							    $(this).tab('show');
							  });
							});
						</script>

					<div class="row">
						<div class="col-md-6 animate-box" data-animate-effect="fadeInTop">
							<div class="project" style="background-image: url(images/img-1.jpg);">
								<div class="desc">
									<div class="con">
										<h3><a href="work.html">Work 01</a></h3>
										<span>Website</span>
										<p class="icon">
											<!-- <span><a href="#"><i class="icon-share3"></i></a></span>
											<span><a href="#"><i class="icon-eye"></i> 100</a></span>
											<span><a href="#"><i class="icon-heart"></i> 49</a></span> -->
										</p>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-md-12 animate-box">
							<p><a href="#" class="btn btn-primary btn-lg btn-load-more">Load more <i class="icon-reload"></i></a></p>
						</div>
					</div>

				</div>
			</section>

				
					
