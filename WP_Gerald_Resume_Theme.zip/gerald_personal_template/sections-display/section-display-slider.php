
<?php 

$slider_defaults = array(
		array(
			'slider_heading' => esc_html__( 'This is your slider heading', 'geraldhomboy' ),
			'slider_details'  => esc_html__('This is your slider details, write details here.', 'geraldhomboy'),
			'slider_btn_text'  => esc_html__( 'Button Text', 'geraldhomboy' ),
			'slider_btn_link'  => 'www.geraldhomboy.com',
			'slider_btn_icon_class'  => esc_html__('icon-download4', 'geraldhomboy'),
			'slider_image' => get_template_directory_uri().'/images/img_bg_1.jpg',
		),
		array(
			'slider_heading' => esc_html__( 'This is your slider heading', 'geraldhomboy' ),
			'slider_details'  => esc_html__('This is your slider details, write details here.', 'geraldhomboy'),
			'slider_btn_text'  => esc_html__( 'DOWNLOAD CV', 'geraldhomboy' ),
			'slider_btn_link'  => 'www.geraldhomboy.com',
			'slider_btn_icon_class'  => esc_html__('icon-download4', 'geraldhomboy'),
			'slider_image' => get_template_directory_uri().'/images/img_bg_2.jpg',
		),
	);

$slider_settings = get_theme_mod( 'sec_slider_settings', $slider_defaults ); ?>

<section id="colorlib-hero" class="js-fullheight" data-section="home">
				<div class="flexslider js-fullheight">
					<ul class="slides">

					<?php foreach ($slider_settings as $slider_setting): ?>
					<?php if (!wp_attachment_is_image( $slider_setting['slider_image'] ) ) {
							$img_url = esc_url_raw($slider_setting['slider_image'] );
						} else {
							$img_url = wp_get_attachment_url($slider_setting['slider_image'] );
						}
					 ?>	
						<li style="background-image: url(<?php echo $img_url; ?>">
				   		<div class="overlay"></div>
				   		<div class="container-fluid">
				   			<div class="row">
					   			<div class="col-md-6 col-md-offset-3 col-md-pull-3 col-sm-12 col-xs-12 js-fullheight slider-text">
					   				<div class="slider-text-inner js-fullheight">
					   					<div class="desc">
						   					<h1><?php echo $slider_setting['slider_heading']; ?></h1>
						   					<h2><?php echo $slider_setting['slider_details']; ?></h2>
												<p><a href ="<?php echo esc_url_raw($slider_setting['slider_btn_link']); ?>" class="btn btn-primary btn-learn"><?php echo $slider_setting['slider_btn_text']; ?> <i class="<?php echo $slider_setting['slider_btn_icon_class']; ?>"></i></a></p>
											</div>
					   				</div>
					   			</div>
					   		</div>
				   		</div>
				   	</li>

				  	<?php endforeach; ?>
<!-- 
				   	

				   	<li style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/img_bg_2.jpg);">
				   		<div class="overlay"></div>
				   		<div class="container-fluid">
				   			<div class="row">
					   			<div class="col-md-6 col-md-offset-3 col-md-pull-3 col-sm-12 col-xs-12 js-fullheight slider-text">
					   				<div class="slider-text-inner">
					   					<div class="desc">
						   					<h1>I am <br>a Designer</h1>
												<h2>100% html5 bootstrap templates Made by <a href="https://colorlib.com/" target="_blank">colorlib.com</a></h2>
												<p><a class="btn btn-primary btn-learn">View Portfolio <i class="icon-briefcase3"></i></a></p>
											</div>
					   				</div>
					   			</div>
					   		</div>
				   		</div>
				   	</li> -->


				  	</ul>
			  	</div>
			</section>