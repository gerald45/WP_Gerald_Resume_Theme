<section class="colorlib-services" data-section="services">
				<div class="colorlib-narrow-content">
					<div class="row">
						<div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
							<span class="heading-meta"><?php echo get_theme_mod( 'sec_title_services'); ?></span>
							<h2 class="colorlib-heading"><?php echo get_theme_mod( 'sec_heading_services'); ?></h2>
						</div>
					</div>

					<?php $services_expertise_settings = get_theme_mod( 'sec_expertise_services');

								//Columns must be a factor of 12 (1,2,3,4,6,12)
								$numOfCols = 3;
								$rowCount = 0;
								$bootstrapColWidth = 12 / $numOfCols;
								$color = 1;
							?>
							<div class="row row-pt-md">
							<?php foreach( $services_expertise_settings as $services_expertise_setting ) :?>  
									<div class="col-md-<?php echo $bootstrapColWidth; ?> text-center animate-box">
										<div class="services color-<?php echo $color; ?>">
											<span class="icon">
												<i class="<?php echo $services_expertise_setting['expertise_icon_class'];  ?>"></i>
											</span>
											<style>
												.services.color-<?php echo $color; ?> .icon {background: <?php echo $services_expertise_setting['expertise_icon_bkg_clr'];  ?> }
												.services.color-<?php echo $color; ?> .icon:before {
													border-color: transparent transparent <?php echo $services_expertise_setting['expertise_icon_bkg_clr'];  ?> transparent;
												}
												.services.color-<?php echo $color; ?> .icon:after {
													    border-color: <?php echo $services_expertise_setting['expertise_icon_bkg_clr'];  ?> transparent transparent transparent;
												}
												.services.color-<?php echo $color; ?> {
													    border-bottom: 2px solid <?php echo $services_expertise_setting['expertise_icon_bkg_clr'];  ?>;
												}
											</style>
											<div class="desc">
												<h3><?php echo $services_expertise_setting['expertise_title'];  ?></h3>
												<p><?php echo $services_expertise_setting['expertise_descp'];  ?></p>
											</div>
										</div>
									</div>

							<?php
									$color++;
								    $rowCount++;
								    if($rowCount % $numOfCols == 0) echo '</div><div class="row row-pt-md">';
								 endforeach; 
								 unset($numOfCols, $rowCount, $bootstrapColWidth, $color);
							 ?>
							
							</div>

				</div>
			</section>