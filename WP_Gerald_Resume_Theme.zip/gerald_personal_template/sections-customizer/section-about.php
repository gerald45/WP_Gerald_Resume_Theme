<?php

/*	notes (see kirki-config.php):
*	config_id: gerald_theme_config 
*	panel_id: homepage_customizer
*	text-domain: geraldhomboy
*/




//add section
Kirki::add_section( 'section_about', array(
    'title'          => esc_html__( 'About Section', 'geraldhomboy' ),
    'description'    => esc_html__( 'Manage About Section:', 'geraldhomboy' ),
    'panel'          => 'homepage_customizer',
    'priority'       => 2,
) );





Kirki::add_field( 'theme_config_id', array(
	'type'        => 'select',
	'settings'    => 'selecttest_setting',
	'label'       => esc_html__( 'This is the label', 'textdomain' ),
	'section'     => 'section_about',
	'default'     => 42,
	'priority'    => 1,
	'choices'     => Kirki_Helper::get_posts( array( 'post_status' => 'publish') ),
) );

//add field
Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'checkbox',
	'settings' => 'sec_option_about',
	'label'    => __( 'Include Section', 'gerald' ),
	'section'  => 'section_about',
	'default'  =>true,
	'priority' => 1,
) );

Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'text',
	'settings' => 'sec_title_about',
	'label'    => __( 'About Title', 'gerald' ),
	'section'  => 'section_about',
	'default'  => esc_html__( 'ABOUT US', 'geraldhomboy' ),
	'priority' => 2,
) );

Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'text',
	'settings' => 'sec_heading_about',
	'label'    => __( 'About Heading', 'geraldhomboy' ),
	'section'  => 'section_about',
	'default'  => esc_html__( 'WHO AM I?', 'geraldhomboy' ),
	'priority' => 3,
) );

Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'textarea',
	'settings' => 'sec_p_about',
	'label'    => __( 'Describe Yourself', 'geraldhomboy' ),
	'section'  => 'section_about',
	'default'  => 'Write about yourself here. Everything you have lorem ipsum, dolor.',
	'priority' => 4,
) );

//icons
Kirki::add_field( 'gerald_theme_config', array(
	'type'        => 'repeater',
	'label'       => esc_html__( 'Expertise', 'geraldhomboy' ),
	'section'     => 'section_about',
	'priority'    => 5,
	'row_label' => array(
		'type' => 'text',
		'value' => esc_html__('Expertise', 'geraldhomboy' ),
	),
	'button_label' => esc_html__('Add new expertise', 'geraldhomboy' ),
	'settings'     => 'sec_expertise_about',
	'default'      => array(
		array(
			'expertise_icon_class' => esc_html__( 'icon-bulb' ),
			'expertise_title'  => esc_html__('Graphic Design', 'geraldhomboy'),
			'expertise_icon_color' => '#2c98f0',
			'expertise_border_color' => '#2c98f0',
		),
		array(
			'expertise_icon_class' => esc_html__( 'icon-globe-outline' ),
			'expertise_title'  => esc_html__('Web Design', 'geraldhomboy'),
			'expertise_icon_color' => '#ec5453',
			'expertise_border_color' => '#ec5453',
		),
		array(
			'expertise_icon_class' => esc_html__( 'icon-data' ),
			'expertise_title'  => esc_html__('Software', 'geraldhomboy'),
			'expertise_icon_color' => '#f9bf3f',
			'expertise_border_color' => '#f9bf3f',
		),
		array(
			'expertise_icon_class' => esc_html__( 'icon-phone3' ),
			'expertise_title'  => esc_html__('Application', 'geraldhomboy'),
			'expertise_icon_color' => '#a84cb8',
			'expertise_border_color' => '#a84cb8',
		)
	),
	'fields' => array(
		'expertise_icon_class' => array(
			'type'        => 'text',
			'label'       => esc_html__( 'Icon Class', 'geraldhomboy' ),
			'default'     => '',
		),
		'expertise_title' => array(
			'type'        => 'text',
			'label'       => esc_html__( 'Expertise Title', 'geraldhomboy' ),
			'default'     => '',
		),
		'box_animation' => array(
			'type'        => 'select',
			'label'       => esc_html__( 'Animation', 'geraldhomboy' ),
			'multiple'    => 1,
			'default'     => 'option-1',
			'choices'     => array(
				'option-1' => esc_html__( 'fadeInLeft', 'geraldhomboy' ),
				'option-2' => esc_html__( 'fadeInRight', 'geraldhomboy' ),
				'option-3' => esc_html__( 'fadeInTop', 'geraldhomboy' ),
				'option-4' => esc_html__( 'fadeInBottom', 'geraldhomboy' ),
			),
		),
		'expertise_icon_color' => array(
			'type'        => 'color',
			'label'       => __( 'Icon Color', 'geraldhomboy' ),
		),
		'expertise_border_color' => array(
			'type'        => 'color',
			'label'       => __( 'Border Color', 'geraldhomboy' ),
		),
	)
) );

Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'textarea',
	'settings' => 'sec_call_action_about',
	'label'    => __( 'Call Action Text', 'geraldhomboy' ),
	'section'  => 'section_about',
	'default'  => 'I am happy to know you that 300+ projects done successfully!',
	'priority' => 6,
) );

Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'text',
	'settings' => 'sec_call_action_about_btn_text',
	'label'    => __( 'Button Text', 'geraldhomboy' ),
	'section'  => 'section_about',
	'default'  => esc_html__('HIRE ME!'),
	'priority' => 7,
) );

Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'text',
	'settings' => 'sec_call_action_about_btn_url',
	'label'    => __( 'Link', 'geraldhomboy' ),
	'section'  => 'section_about',
	'default'  => 'www.geraldhomboy.com',
	'priority' => 8,
) );