<?php

/*	notes (see kirki-config.php):
*	config_id: gerald_theme_config 
*	panel_id: homepage_customizer
*	text-domain: geraldhomboy
*/
//add section
Kirki::add_section( 'section_services', array(
    'title'          => esc_html__( 'Services Section', 'geraldhomboy' ),
    'description'    => esc_html__( 'Manage Services Section:', 'geraldhomboy' ),
    'panel'          => 'homepage_customizer',
    'priority'       => 3,
) );

//add field
Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'text',
	'settings' => 'sec_title_services',
	'label'    => __( 'Services Title', 'gerald' ),
	'section'  => 'section_services',
	'default'  => esc_html__( 'WHAT I DO', 'geraldhomboy' ),
	'priority' => 1,
) );

Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'text',
	'settings' => 'sec_heading_services',
	'label'    => __( 'Services Heading', 'geraldhomboy' ),
	'section'  => 'section_services',
	'default'  => esc_html__( 'HERE ARE SOME OF MY EXPERTISE', 'geraldhomboy' ),
	'priority' => 2,
) );


//icons
Kirki::add_field( 'gerald_theme_config', array(
	'type'        => 'repeater',
	'label'       => esc_html__( 'Expertise', 'geraldhomboy' ),
	'section'     => 'section_services',
	'priority'    => 4,
	'row_label' => array(
		'type' => 'text',
		'value' => esc_html__('Expertise', 'geraldhomboy' ),
	),
	'button_label' => esc_html__('Add new expertise', 'geraldhomboy' ),
	'settings'     => 'sec_expertise_services',
	'default'      => array(
		array(
			'expertise_icon_class' => esc_html__( 'icon-bulb', 'geraldhomboy'),
			'expertise_icon_bkg_clr' => '#2c98f0',
			'expertise_title'  => esc_html__('INNOVATIVE IDEAS', 'geraldhomboy'),
			'expertise_descp' => esc_html__('Separated they live in Bookmarksgrove right at the coast of the Semantics', 'geraldhomboy'),
		),
		array(
			'expertise_icon_class' => esc_html__( 'icon-bulb', 'geraldhomboy'),
			'expertise_icon_bkg_clr' => '#2c98f0',
			'expertise_title'  => esc_html__('INNOVATIVE IDEAS', 'geraldhomboy'),
			'expertise_descp' => esc_html__('Separated they live in Bookmarksgrove right at the coast of the Semantics', 'geraldhomboy'),
		),
		array(
			'expertise_icon_class' => esc_html__( 'icon-bulb', 'geraldhomboy'),
			'expertise_icon_bkg_clr' => '#2c98f0',
			'expertise_title'  => esc_html__('INNOVATIVE IDEAS', 'geraldhomboy'),
			'expertise_descp' => esc_html__('Separated they live in Bookmarksgrove right at the coast of the Semantics', 'geraldhomboy'),
		)
	),
	'fields' => array(
		'expertise_icon_class' => array(
			'type'        => 'text',
			'label'       => esc_html__( 'Icon Class', 'geraldhomboy' ),
			'default'     => '',
		),
		'expertise_icon_bkg_clr' => array(
			'type'        => 'color',
			'label'       => __( 'Icon Background Color', 'geraldhomboy' ),
			'default'     => '',
		),
		'expertise_title' => array(
			'type'        => 'text',
			'label'       => esc_html__( 'Expertise Title', 'geraldhomboy' ),
			'default'     => '',
		),
		'expertise_descp' => array(
			'type'        => 'textarea',
			'label'       => esc_html__( 'Describe your expertise', 'geraldhomboy' ),
			'default'     => '',
		)
	)
) );
