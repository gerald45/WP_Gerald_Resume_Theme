<?php

/*	notes (see inc/kirki-config.php):
*	config_id: gerald_theme_config 
*	panel_id: homepage_customizer
*	text-domain: geraldhomboy
*/
//add section
Kirki::add_section( 'section_counter', array(
    'title'          => esc_html__( 'Counter Section', 'geraldhomboy' ),
    'description'    => esc_html__( 'Manage Counter Settings:', 'geraldhomboy' ),
    'panel'          => 'homepage_customizer',
    'priority'       => 4,
) );

//add field
Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'text',
	'settings' => 'sec_data_speed_services',
	'label'    => __( 'Data Speed', 'gerald' ),
	'description' => __('Integer Value Only'),
	'section'  => 'section_counter',
	'default'  => 5000,
	'priority' => 1,
) );

Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'text',
	'settings' => 'sec_data_rfsh_interval_services',
	'label'    => __( 'Refresh Interval', 'gerald' ),
	'description' => __('Integer Value Only', 'gerald'),
	'section'  => 'section_counter',
	'default'  => 50,
	'priority' => 2,
) );

//counter data
Kirki::add_field( 'gerald_theme_config', array(
	'type'        => 'repeater',
	'label'       => esc_html__( 'Counter', 'geraldhomboy' ),
	'section'     => 'section_counter',
	'priority'    => 3,
	'row_label' => array(
		'type' => 'text',
		'value' => esc_html__('Counter', 'geraldhomboy' ),
	),
	'button_label' => esc_html__('Add new counter', 'geraldhomboy' ),
	'settings'     => 'sec_data_counter',
	'default'      => array(
		array(
			'counter_data_value' => esc_html__( '309', 'geraldhomboy'),
			'counter_title' => esc_html__( 'CUPS OF COFFEE', 'geraldhomboy'),
		),
		array(
			'counter_data_value' => esc_html__( '356', 'geraldhomboy'),
			'counter_title' => esc_html__( 'PROJECTS', 'geraldhomboy'),
		),
		array(
			'counter_data_value' => esc_html__( '30', 'geraldhomboy'),
			'counter_title' => esc_html__( 'CLIENTS', 'geraldhomboy'),
		),
		array(
			'counter_data_value' => esc_html__( '10', 'geraldhomboy'),
			'counter_title' => esc_html__( 'PARTNERS', 'geraldhomboy'),
		)
	),
	'fields' => array(
		'counter_data_value' => array(
			'type'        => 'text',
			'label'       => esc_html__( 'Count to Value', 'geraldhomboy' ),
			'default'     => '',
		),
		'counter_title' => array(
			'type'        => 'text',
			'label'       => __( 'Counter Name', 'geraldhomboy' ),
			'default'     => '',
		)
	)
) );

Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'image',
	'settings' => 'sec_counter_image',
	'label'    => __( 'Background Image', 'gerald' ),
	'description' => __('Upload Image', 'gerald'),
	'section'  => 'section_counter',
	'default'  => get_template_directory_uri().'/images/cover_bg_1.jpg',
	'priority' => 4,
) );
