<?php

/*	notes (see kirki-config.php):
*	config_id: gerald_theme_config 
*	panel_id: homepage_customizer
*	text-domain: geraldhomboy
*/
//add section
Kirki::add_section( 'section_education', array(
    'title'          => esc_html__( 'Education Section', 'geraldhomboy' ),
    'description'    => esc_html__( 'Manage Education Section:', 'geraldhomboy' ),
    'panel'          => 'homepage_customizer',
    'priority'       => 6,
) );

//add field
Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'text',
	'settings' => 'sec_title_education',
	'label'    => __( 'Education Title', 'gerald' ),
	'section'  => 'section_education',
	'default'  => esc_html__( 'EDUCATION', 'geraldhomboy' ),
	'priority' => 1,
) );

Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'text',
	'settings' => 'sec_heading_education',
	'label'    => __( 'Education Heading', 'geraldhomboy' ),
	'section'  => 'section_education',
	'default'  => esc_html__( 'EDUCATION', 'geraldhomboy' ),
	'priority' => 2,
) );


//add education
Kirki::add_field( 'gerald_theme_config', array(
	'type'        => 'repeater',
	'label'       => esc_html__( 'EDUCATION', 'geraldhomboy' ),
	'section'     => 'section_education',
	'priority'    => 3,
	'row_label' => array(
		'type' => 'text',
		'value' => esc_html__('Education', 'geraldhomboy' ),
	),
	'button_label' => esc_html__('Add new education', 'geraldhomboy' ),
	'settings'     => 'sec_education_list',
	'default'      => array(
		array(
			'education_level'  => esc_html__('Bachelor Degree of Computer Science', 'geraldhomboy'),
			'education_details'  => 'Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.',
		)
	),
	'fields' => array(
		'education_level' => array(
			'type'        => 'text',
			'label'       => esc_html__( 'Education Level/Courses', 'geraldhomboy' ),
			'description' => esc_html__( 'Define degree courses or diploma', 'geraldhomboy' ),
			'default'     => '',
		),
		'education_details' => array(
			'type'        => 'textarea',
			'label'       => esc_html__( 'Describe your acheivements', 'geraldhomboy' ),
			'default'     => '',
		)
	)
) );

