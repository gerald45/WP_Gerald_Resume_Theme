<?php

/*	notes (see kirki-config.php):
*	config_id: gerald_theme_config 
*	panel_id: homepage_customizer
*/
//add section
Kirki::add_section( 'section_slider', array(
    'title'          => esc_html__( 'Slider Section', 'geraldhomboy' ),
    'description'    => esc_html__( 'Manage Sliders Below:', 'geraldhomboy' ),
    'panel'          => 'homepage_customizer',
    'priority'       => 1,
) );


//add fields
Kirki::add_field( 'gerald_theme_config', array(
	'type'        => 'repeater',
	'label'       => esc_html__( 'Sliders', 'geraldhomboy' ),
	'section'     => 'section_slider',
	'priority'    => 10,
	'row_label' => array(
		'type' => 'text',
		'value' => esc_html__('Slider', 'geraldhomboy' ),
	),
	'button_label' => esc_html__('Add new slide', 'geraldhomboy' ),
	'settings'     => 'sec_slider_settings',
	'default'      => array(
		array(
			'slider_heading' => esc_html__( 'This is your slider heading', 'geraldhomboy' ),
			'slider_details'  => 'This is your slider details, write details here.', 'geraldhomboy',
			'slider_btn_text'  => esc_html__( 'Button Text', 'geraldhomboy' ),
			'slider_btn_link'  => 'www.geraldhomboy.com',
			'slider_btn_icon_class'  => esc_html__('icon-download4', 'geraldhomboy'),
			'slider_image' => get_template_directory_uri().'/images/img_bg_1.jpg',
		),
		array(
			'slider_heading' => esc_html__( 'This is your slider heading', 'geraldhomboy' ),
			'slider_details'  => 'This is your slider details, write details here.', 'geraldhomboy',
			'slider_btn_text'  => esc_html__( 'DOWNLOAD CV', 'geraldhomboy' ),
			'slider_btn_link'  => 'www.geraldhomboy.com',
			'slider_btn_icon_class'  => esc_html__('icon-download4', 'geraldhomboy'),
			'slider_image' => get_template_directory_uri().'/images/img_bg_2.jpg',
		)
	),
	'fields' => array(
		'slider_heading' => array(
			'type'        => 'text',
			'label'       => esc_html__( 'Heading', 'geraldhomboy' ),
			'default'     => '',
		),
		'slider_details' => array(
			'type'        => 'textarea',
			'label'       => 'Details', 'geraldhomboy' ,
			'default'     => '',
		),
		'slider_btn_text' => array(
			'type'        => 'text',
			'label'       => esc_html__( 'Button Text', 'geraldhomboy' ),
			'default'     => '',
		),
		'slider_btn_link' => array(
			'type'        => 'text',
			'label'       => esc_html__( 'Button Link', 'geraldhomboy' ),
			'default'     => '',
		),
		'slider_btn_icon_class' => array(
			'type'        => 'text',
			'label'       => esc_html__( 'Button Icon Class', 'geraldhomboy' ),
			'default'     => '',
		),
		'slider_image' => array(
			'type'        => 'image',
			'label'       => esc_html__( 'Background Image', 'geraldhomboy' ),
			'default'     => '',
		)
	)
) );
