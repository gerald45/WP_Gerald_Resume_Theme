<?php

/*	notes (see kirki-config.php):
*	config_id: gerald_theme_config 
*	panel_id: homepage_customizer
*	text-domain: geraldhomboy
*/
//add section
Kirki::add_section( 'section_skills', array(
    'title'          => esc_html__( 'Skills Section', 'geraldhomboy' ),
    'description'    => esc_html__( 'Manage Skills Section:', 'geraldhomboy' ),
    'panel'          => 'homepage_customizer',
    'priority'       => 5,
) );

//add field
Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'text',
	'settings' => 'sec_title_skills',
	'label'    => __( 'Skills Title', 'gerald' ),
	'section'  => 'section_skills',
	'default'  => esc_html__( 'MY SPECIALTY', 'geraldhomboy' ),
	'priority' => 1,
) );

Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'text',
	'settings' => 'sec_heading_skills',
	'label'    => __( 'Skills Heading', 'geraldhomboy' ),
	'section'  => 'section_skills',
	'default'  => esc_html__( 'MY SKILLS', 'geraldhomboy' ),
	'priority' => 2,
) );

Kirki::add_field( 'gerald_theme_config', array(
	'type'     => 'textarea',
	'settings' => 'sec_p_skills',
	'label'    => __( 'Describe Your Skills', 'geraldhomboy' ),
	'section'  => 'section_skills',
	'default'  => 'The Big Oxmox advised her not to do so, because there were thousands of bad Commas, wild Question Marks and devious Semikoli, but the Little Blind Text didn’t listen. She packed her seven versalia, put her initial into the belt and made herself on the way.',
	'priority' => 3,
) );

//slider range
Kirki::add_field( 'gerald_theme_config', array(
	'type'        => 'repeater',
	'label'       => esc_html__( 'Skills', 'geraldhomboy' ),
	'section'     => 'section_skills',
	'priority'    => 4,
	'row_label' => array(
		'type' => 'text',
		'value' => esc_html__('Skills', 'geraldhomboy' ),
	),
	'button_label' => esc_html__('Add new skill', 'geraldhomboy' ),
	'settings'     => 'sec_expertise_skills',
	'default'      => array(
		array(
			'slider_range_title'  => esc_html__('Photoshop', 'geraldhomboy'),
			'slider_range_value'  => 80,
			'slider_range__clr' => '#2c98f0',
			'slider_range__animate' => 'fadeInLeft',
		),
		array(
			'slider_range_title'  => esc_html__('jQuery', 'geraldhomboy'),
			'slider_range_value'  => 80,
			'slider_range__clr' => '#2c98f0',
			'slider_range__animate' => 'fadeInLeft',
		)
	),
	'fields' => array(
		'slider_range_value' => array(
			'type'        => 'text',
			'label'       => esc_html__( 'Skill Rate', 'geraldhomboy' ),
			'description' => esc_html__( 'Rate from 1 to 100 only', 'geraldhomboy' ),
			'default'     => '',
		),
		'slider_range_title' => array(
			'type'        => 'text',
			'label'       => esc_html__( 'Skill Title', 'geraldhomboy' ),
			'default'     => '',
		),
		'slider_range__clr' => array(
			'type'        => 'color',
			'label'       => esc_html__( 'Skill Color', 'geraldhomboy' ),
			'default'     => '',
		)
	)
) );
