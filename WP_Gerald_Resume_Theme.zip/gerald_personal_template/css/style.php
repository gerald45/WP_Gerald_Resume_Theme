<?php
    header("Content-type: text/css; charset: UTF-8");

?>

